package com.huayu.springbootdemo.entity;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.entity
 * @Author: huayu
 * @CreateTime: 2019-05-12 05:55
 * @Description: todo
 **/
public class User {
    private String id;
    private String username;
    private String password;

    public String getpassword() {
        return password;
    }
    public void setpassword(String password) {
        this.password = password;
    }
    public String getUsername() {
        return username;
    }
    public void setName(String name) {
        this.username = name;
    }
    public void setId(String id){this.id = id;}
    public String getId() { return id; }

    public String toString(){
        return "id="+id+" "+"name:"+username+" "+"password="+password;
    }
}
