package com.huayu.springbootdemo.service;

import com.huayu.springbootdemo.dao.Userdao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.service
 * @Author: huayu
 * @CreateTime: 2019-05-15 05:17
 * @Description: todo
 **/
@Service
public class UserService {
    @Autowired
    private Userdao userdao;

    //调用dao层的insert方法
    public boolean insert(String username, String password) {
        return userdao.insert(username, password);
    }

    //调用dao层的delect方法
    public boolean delect(String username, String password) {
        return userdao.delete(username, password);
    }

    //调用dao层的update方法
    public boolean update(String newPW, String username, String password) {
        return userdao.update(newPW, username, password);
    }
}
