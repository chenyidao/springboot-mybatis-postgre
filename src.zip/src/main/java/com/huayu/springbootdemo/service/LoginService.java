package com.huayu.springbootdemo.service;

import com.huayu.springbootdemo.dao.Logindao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.service
 * @Author: huayu
 * @CreateTime: 2019-05-13 05:10
 * @Description: todo
 **/

@Service
public class LoginService {
    @Autowired
    private Logindao common;

    //调用dao层的login方法
    public String login(String username, String password) {
        return common.login(username, password);
    }

}
