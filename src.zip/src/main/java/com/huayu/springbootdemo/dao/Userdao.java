package com.huayu.springbootdemo.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.dao
 * @Author: huayu
 * @CreateTime: 2019-05-15 05:17
 * @Description: todo
 **/

@Component
public interface Userdao {
    //数据库中插入用户
    @Insert("INSERT INTO \"user\" VALUES(#{username},#{password})")
    boolean insert(@Param("username")String username, @Param("password")String password);

    //数据库中删除用户
    @Delete("DELETE FROM \"user\" WHERE username=#{username} and \"password\"=#{password}")
    boolean delete(@Param("username")String username,@Param("password")String password);

    //数据库中更新用户
    @Update("UPDATE \"user\" SET \"password\"=#{newPW} WHERE \"username\"=#{username} AND \"password\"=#{oldPW}")
    boolean update(@Param("newPW")String newPW,@Param("username")String username,@Param("oldPW")String oldPW);
}
