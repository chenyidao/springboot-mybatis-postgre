package com.huayu.springbootdemo.dao;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.dao
 * @Author: huayu
 * @CreateTime: 2019-05-13 05:03
 * @Description: todo
 **/

@Component
public interface Logindao {

    //数据库中查找@Select注解
    @Select("SELECT username FROM \"public\".\"user\" WHERE username=#{username} and password=#{password}")
    String login(@Param("username")String username, @Param("password")String password);

}
