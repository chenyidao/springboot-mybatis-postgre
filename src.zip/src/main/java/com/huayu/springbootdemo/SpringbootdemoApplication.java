package com.huayu.springbootdemo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.huayu.springbootdemo.dao")//编译之后生成相应的接口实现类
@SpringBootApplication
public class SpringbootdemoApplication {

    public static void main(String[] args) {
//		System.out.println("Hello World");

        SpringApplication.run(SpringbootdemoApplication.class, args);
    }

}
