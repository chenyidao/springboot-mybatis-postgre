package com.huayu.springbootdemo.controller;

import com.huayu.springbootdemo.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.controller
 * @Author: huayu
 * @CreateTime: 2019-05-13 05:26
 * @Description: todo
 **/

@Controller      //要记得添加这个注解，不然没有页面为404    记得查？
public class LoginController {
    @Autowired    //按照类型自动装配对象
    private LoginService commonservice;

    @RequestMapping("/login")
    public String login() {
        return "/login/login";
    }

    @RequestMapping("/index")
    public String index(){return "/login/index";}

    @RequestMapping(value = "/loginPage", method = {RequestMethod.POST, RequestMethod.GET})
    public String login(HttpServletRequest request,HttpSession session) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        System.out.println("你输入的用户名为：" + username);
        System.out.println("你输入的密码为：" + password);
        String tname = commonservice.login(username, password);
//        System.out.println(tname);
        session.setAttribute("tname", tname);
        if (tname == null) {
            return "redirect:login";   //重新登录的html
        } else {
            return "redirect:index";     //返回登录成功的html
        }
    }

}
