package com.huayu.springbootdemo.controller;

import com.huayu.springbootdemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @BelongsProject: springbootdemo
 * @BelongsPackage: com.huayu.springbootdemo.controller
 * @Author: huayu
 * @CreateTime: 2019-05-15 05:16
 * @Description: todo
 **/
@Controller
public class UserController {
    @Autowired
    private UserService userService;

    //调用user.html
    @RequestMapping("/user")
    public String user(){
        return "/user/user";
    }

    //调用service层的insert方法
    @ResponseBody
    @RequestMapping("/insert")
    public String insert(HttpServletRequest request, HttpSession session) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean result = userService.insert(username, password);
        if (result == true) {
            return "增加用户成功";
        }
        return "增加用户失败";
    }

    //调用service层的delete方法
    @ResponseBody
    @RequestMapping("/delect")
    public String delect(HttpServletRequest request, HttpSession session) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean result = userService.delect(username, password);
        if (result == true) {
            return "删除用户成功";
        } else
            return "删除用户失败";
    }

    //调用service层的insert方法
    @ResponseBody
    @RequestMapping("/update")
    public String update(HttpServletRequest request, HttpSession session) {
        String newPW = request.getParameter("newPW");
        String username = request.getParameter("username");
        String oldPW = request.getParameter("oldPW");
        boolean result = userService.update(newPW, username, oldPW);
        if (result == true) {
            return "更新用户信息成功";
        } else
            return "更新用户信息失败";
    }

}
